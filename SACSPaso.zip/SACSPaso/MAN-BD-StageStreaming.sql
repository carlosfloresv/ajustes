spaddtblTemplate 0,1,'Home 5','','ctrlHomeNuevo5.ascx','tresiteadmin','Templates/manana/images/templates/homenuevo4.jpg','Template Streaming'

select * from tblSiteConfigurationTemplate where strItemName ='StoryTabStage'
select * from tblTemplate 
insert into tblSiteConfigurationTemplate values (83,36)
